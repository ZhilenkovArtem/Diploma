﻿using System;

namespace DataGeneration
{
    class Program
    {
        static void Main()
        {
            Console.WriteLine("Поехали!");

            string path = @"C:\Users\Artem\Desktop\rg2\BrKr_ONBr4_1037.rg2";
            var dataFromRastrWin = GettingDataFromRastrWin3Library.Processing.GetDataFromRastrWin3(path);

            var pathForDataSet = @"C:\Users\Artem\Desktop\dataSet7.dat";
            var pathForTelemetries = @"C:\Users\Artem\Desktop\telemetries7.dat";
            TransformationRastrData.Processing.DataOutput(dataFromRastrWin, pathForDataSet, pathForTelemetries);

            Console.WriteLine("Файлы созданы");
            Console.ReadKey();
        }
    }
}
